#!/bin/bash
# OMEGA VPN MANAGER - INSTALADOR COMPLETO
# Compatível com Debian/Ubuntu

clear
echo "=========================================="
echo "     OMEGA - GERENCIAMENTO VPN AVANÇADO"
echo "=========================================="
echo ""
echo "Iniciando instalação do Omega..."
sleep 2

# Verifica permissão root
if [[ "$EUID" -ne 0 ]]; then
  echo "[ERRO] Este script deve ser executado como root."
  exit 1
fi

# Verifica distribuição
if ! grep -qiE 'debian|ubuntu' /etc/os-release; then
  echo "[ERRO] Este script é compatível apenas com Debian ou Ubuntu."
  exit 1
fi

# Atualiza pacotes
echo "[+] Atualizando pacotes..."
apt-get update -y && apt-get upgrade -y > /dev/null 2>&1

# Instala pacotes e dependências
echo "[+] Instalando dependências..."
apt install -y curl wget unzip socat net-tools lsof cron jq nginx php php-fpm certbot zip git openvpn dropbear sudo ufw > /dev/null 2>&1

# Configura firewall com UFW
ufw allow OpenSSH
ufw allow 80,443,12345,4432/tcp
ufw --force enable

# Cria estrutura de diretórios
mkdir -p /opt/omega/{logs,bin,protocols,web,apks,telegram,backup}

# Instala V2Ray/Xray
echo "[+] Instalando V2Ray e Xray..."
bash <(curl -Ls https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh) > /dev/null 2>&1
bash <(curl -Ls https://github.com/XTLS/Xray-install/raw/main/install-release.sh) > /dev/null 2>&1

# Instala SlowDNS (placeholder)
echo "[+] SlowDNS será configurado manualmente (em desenvolvimento)"

# Instala painel web para Xray (placeholder)
echo "[+] Painel Web Xray..."
echo "Instalação automatizada virá em atualizações futuras."

# Multiplex config (placeholder)
echo "[+] Configuração Multiplex em desenvolvimento..."

# Gerador de domínio gratuito (via Freenom ou DuckDNS)
echo "[+] Configurando domínio gratuito..."
echo "SEUDOMINIO-omega" > /opt/omega/web/domain.txt

# Configuração de upload de APKs
cat <<EOF > /opt/omega/web/index.html
<html><body><h2>Upload de APKs - Omega</h2><form method="post" enctype="multipart/form-data" action="upload.php"><input type="file" name="apk"><input type="submit" value="Enviar"></form></body></html>
EOF
cat <<EOF > /opt/omega/web/upload.php
<?php
move_uploaded_file(\$_FILES["apk"]["tmp_name"], "./apks/" . \$_FILES["apk"]["name"]);
echo "APK enviado com sucesso!";
?>
EOF
chmod -R 755 /opt/omega/web

# Configura NGINX
cat <<EOF > /etc/nginx/sites-available/omega
server {
    listen 80;
    server_name _;
    root /opt/omega/web;
    index index.html;
    location /apks/ {
        autoindex on;
    }
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php-fpm.sock;
    }
}
EOF
ln -sf /etc/nginx/sites-available/omega /etc/nginx/sites-enabled/
systemctl restart nginx

# Bot Telegram
cat <<'EOF' > /opt/omega/telegram/bot.sh
#!/bin/bash
source /opt/omega/telegram/.env
ADMINS=("ID1" "ID2")
OFFSET=0
LOG_FILE="/opt/omega/telegram/logs.txt"

is_admin() {
  local id="$1"
  for admin in "${ADMINS[@]}"; do
    [[ "$id" == "$admin" ]] && return 0
  done
  return 1
}

log_message() {
  echo "$(date) - $1" >> $LOG_FILE
}

while true; do
  UPDATES=$(curl -s "https://api.telegram.org/bot$TOKEN/getUpdates?offset=$OFFSET")
  echo "$UPDATES" | jq -c '.result[]' | while read -r update; do
    OFFSET=$(echo "$update" | jq '.update_id')
    OFFSET=$((OFFSET+1))
    MSG=$(echo "$update" | jq -r '.message.text')
    CHAT_ID=$(echo "$update" | jq -r '.message.chat.id')
    USER=$(echo "$update" | jq -r '.message.from.username')

    log_message "Mensagem recebida de @$USER: $MSG"

    if ! is_admin "$CHAT_ID"; then
      curl -s -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" -d chat_id="$CHAT_ID" -d text="Acesso negado." > /dev/null
      continue
    fi

    case "$MSG" in
      "/start")
        MSG_OUT="Bem-vindo ao Omega VPN Bot, @$USER!" ;;
      "/status")
        MSG_OUT="Servidor ativo. Uptime: $(uptime -p)" ;;
      "/usuarios")
        USUARIOS=$(ps -ef | grep sshd | grep -v grep | wc -l)
        MSG_OUT="Usuários ativos: $USUARIOS" ;;
      /adduser*)
        PARAMS=($MSG)
        if [ ${#PARAMS[@]} -ne 4 ]; then
          MSG_OUT="Uso: /adduser nome senha dias"
        else
          useradd -e $(date -d "+${PARAMS[3]} days" +%Y-%m-%d) -M -s /bin/false ${PARAMS[1]}
          echo "${PARAMS[1]}:${PARAMS[2]}" | chpasswd
          MSG_OUT="Usuário ${PARAMS[1]} criado por ${PARAMS[3]} dias."
        fi
        ;;
      /deluser*)
        USR=$(echo $MSG | cut -d ' ' -f2)
        if id "$USR" &>/dev/null; then
          userdel -f $USR && MSG_OUT="Usuário $USR removido." || MSG_OUT="Erro ao remover." ;;
        else
          MSG_OUT="Usuário não encontrado." ;;
        fi
        ;;
      *)
        MSG_OUT="Comando desconhecido." ;;
    esac

    curl -s -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" \
      -d chat_id="$CHAT_ID" -d text="$MSG_OUT" > /dev/null
  done
  sleep 2
done
EOF

cat <<EOF > /opt/omega/telegram/.env
TOKEN="SEU_TOKEN"
EOF
chmod +x /opt/omega/telegram/bot.sh

# Backup do servidor
cat <<EOF > /opt/omega/backup.sh
#!/bin/bash
BACKUP_DIR=/opt/omega/backup
DATE=$(date +%Y-%m-%d_%H-%M-%S)

# Criar backup de configurações e logs
mkdir -p $BACKUP_DIR
cp -r /opt/omega/logs $BACKUP_DIR/logs_$DATE
cp -r /opt/omega/bin $BACKUP_DIR/bin_$DATE
cp -r /opt/omega/protocols $BACKUP_DIR/protocols_$DATE
tar -czf $BACKUP_DIR/backup_$DATE.tar.gz $BACKUP_DIR/*

# Remover backups antigos (mais de 7 dias)
find $BACKUP_DIR -type f -name '*.tar.gz' -mtime +7 -exec rm -f {} \;
EOF
chmod +x /opt/omega/backup.sh

# Menu principal
cat <<EOF > /opt/omega/omega.sh
#!/bin/bash
clear
echo "==================================="
echo "        MENU PRINCIPAL OMEGA"
echo "==================================="
echo "1) Gerenciar usuários"
echo "2) Instalar protocolo"
echo "3) Painel Web / Domínio"
echo "4) Telegram Bot"
echo "5) Upload de APKs"
echo "6) Backup do servidor"
echo "7) Sair"
read -p "Opção: " opcao
case \$opcao in
  1) echo "Gestão de usuários em breve..." ;;
  2) echo "Escolha de protocolos será adicionada..." ;;
  3) echo "Domínio e painel web configurados em /opt/omega/web" ;;
  4) bash /opt/omega/telegram/bot.sh ;;
  5) echo "Acesse via navegador: http://\$(hostname -I | awk '{print \$1}')/apks/" ;;
  6) bash /opt/omega/backup.sh ;;
  7) exit 0 ;;
  *) echo "Opção inválida" ;;
esac
EOF
chmod +x /opt/omega/omega.sh
ln -sf /opt/omega/omega.sh /usr/local/bin/omega

# Finalização
echo ""
echo "[✓] Instalação completa do Omega finalizada!"
echo "Use o comando: omega"
echo "para iniciar o painel de gerenciamento."
echo ""
echo "Upload de APK: http://SEU_IP/apks/"
echo "Painel Web (em desenvolvimento): http://SEU_IP"
echo "Para usar o bot Telegram, edite /opt/omega/telegram/.env com seu TOKEN e execute pelo menu."
